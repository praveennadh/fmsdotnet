namespace fleetsystem.dtos
{
    public class TruckResponse
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Model { get; set; }
        public int Year { get; set; }
    }
}