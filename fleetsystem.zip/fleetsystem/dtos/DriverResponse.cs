namespace fleetsystem.dtos
{
    public class DriverResponse
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? License { get; set; }
        public string? Details { get; set; }
    }
}