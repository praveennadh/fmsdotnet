namespace fleetsystem.dtos
{
    public class TruckRequest
    {
        public string? Name { get; set; }
        public string? Model { get; set; }
        public int Year { get; set; }
    }
}