namespace fleetsystem.dtos
{
    public class DriverRequest
    {
        public string? Name { get; set; }
        public string? License { get; set; }
        public string? Details { get; set; }
    }
}